=== DENTIA CHAIRSIDE HARDWARE SETUP ===

PREREQUISITES:
1. Windows 10 or 11 (64-bit)
2. Node.js installed (free download from https://nodejs.org/ if not already installed)
3. Eighteeth Nano-Pix sensor connected to a USB 2.0 port

1-MINUTE INSTALLATION:
Step 1: Double-click "REGISTER_DENTIA_PROTOCOL.bat"
  - Registers the "dentia-hw://" browser auto-launch protocol.
  - Adds the bridge to Windows Startup (auto-runs on boot).
  - Starts the background bridge immediately on Port 5066.

Step 2: Open https://dentistfrontend.vercel.app/ in Google Chrome / Edge
  - Click the "Hardware" icon in the navigation bar.
  - Click "Launch Hardware Agent Now".
  - Chrome will show a dialog: "Open Dentia Hardware Protocol? dentistfrontend.vercel.app wants to open this application."
  - Check the box "Always allow dentistfrontend.vercel.app to open links of this type" and click [Open Dentia Hardware Protocol].
  - Your sensor status will show "All Systems Operational" (Active & Synced).

TROUBLESHOOTING:
- If Chrome blocks localhost on HTTPS (Vercel):
  Click the Tune/Lock icon next to the URL -> Site Settings -> Insecure Content -> Allow.
- To start the bridge manually at any time:
  Double-click "START_NANOPIX_AUTO_SYNC.bat".
