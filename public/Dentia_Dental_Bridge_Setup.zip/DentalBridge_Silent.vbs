Set WshShell = CreateObject("WScript.Shell")
WshShell.Run chr(34) & "C:\ProgramData\DentalBridge\bin\DentalBridge.exe" & chr(34) & " --workdir " & chr(34) & "C:\ProgramData\DentalBridge\bin" & chr(34) & " --background", 0, False
