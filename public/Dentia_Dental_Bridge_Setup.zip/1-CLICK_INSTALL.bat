@echo off
TITLE Dentia Dental Hardware Bridge - 1-Click Clinic Setup
color 0A

echo ==============================================================================
echo   DENTIA HARDWARE BRIDGE - AUTOMATED 1-CLICK CLINIC SETUP
echo   Eighteeth NanoPix 1.5 & NanoPix 2 Direct USB Web Integration
echo ==============================================================================
echo.

set "TARGET_DIR=%ProgramData%\DentalBridge\bin"
set "LOGS_DIR=%ProgramData%\DentalBridge\logs"
set "CAPTURES_DIR=%ProgramData%\DentalBridge\captures"
set "SOURCE_DIR=%~dp0"

echo [*] Target Directory:   %TARGET_DIR%
echo [*] Logs Directory:     %LOGS_DIR%
echo [*] Captures Directory: %CAPTURES_DIR%
echo.
echo [*] Creating clinic directories...
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
if not exist "%LOGS_DIR%" mkdir "%LOGS_DIR%"
if not exist "%CAPTURES_DIR%" mkdir "%CAPTURES_DIR%"
if not exist "%TARGET_DIR%\Correct\Default" mkdir "%TARGET_DIR%\Correct\Default"

:: Terminate any previous instance
taskkill /F /IM DentalBridge.exe >nul 2>&1

echo [*] Installing runtime binaries, native drivers, and calibration profiles...
copy /Y "%SOURCE_DIR%DentalBridge.exe" "%TARGET_DIR%\" >nul
copy /Y "%SOURCE_DIR%*.dll" "%TARGET_DIR%\" >nul
copy /Y "%SOURCE_DIR%config.ini" "%TARGET_DIR%\" >nul
copy /Y "%SOURCE_DIR%WebSocket_Live_Monitor.html" "%TARGET_DIR%\" >nul
if exist "%SOURCE_DIR%Correct" (
    xcopy /E /I /Y "%SOURCE_DIR%Correct" "%TARGET_DIR%\Correct\" >nul
)

:: Validate installation
if not exist "%TARGET_DIR%\DentalBridge.exe" (
    color 0C
    echo [ERROR] Failed to copy DentalBridge.exe! Please run this batch file as Administrator.
    pause
    exit /b 1
)

echo [*] Registering Windows Auto-Start...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "DentiaDentalBridge" /t REG_SZ /d "\"%TARGET_DIR%\DentalBridge.exe\"" /f >nul 2>&1

echo [*] Configuring local loopback network firewall (Port 5050)...
netsh advfirewall firewall add rule name="Dentia Dental Bridge (Port 5050)" dir=in action=allow protocol=TCP localport=5050 >nul 2>&1

echo [*] Creating Desktop shortcuts...
powershell -NoProfile -Command "$w=New-Object -ComObject WScript.Shell;$d=[Environment]::GetFolderPath('Desktop');$s=$w.CreateShortcut(\"$d\Dentia Dental Bridge.lnk\");$s.TargetPath=\"%TARGET_DIR%\DentalBridge.exe\";$s.WorkingDirectory=\"%TARGET_DIR%\";$s.Save();$s2=$w.CreateShortcut(\"$d\Dentia Live Monitor.lnk\");$s2.TargetPath=\"%TARGET_DIR%\WebSocket_Live_Monitor.html\";$s2.Save();$s3=$w.CreateShortcut(\"$d\Dentia Bridge Data Folder.lnk\");$s3.TargetPath=\"%ProgramData%\DentalBridge\";$s3.Save();"

echo [*] Launching Dental Bridge background service...
start "" "%TARGET_DIR%\DentalBridge.exe"

timeout /t 3 >nul
powershell -NoProfile -Command "try { $r = Invoke-RestMethod -Uri 'http://127.0.0.1:5050/api/status' -TimeoutSec 3; Write-Host ' [STATUS CHECK] Bridge is active on port 5050! Status:' $r.status 'Model:' $r.model } catch { Write-Host ' [STATUS NOTE] Service starting up in background...' }"

echo.
echo ==============================================================================
echo   SUCCESS! Dentia Hardware Bridge is now active on ws://127.0.0.1:5050
echo   Desktop shortcuts created:
echo     1. Dentia Dental Bridge (Starts the service)
echo     2. Dentia Live Monitor (Opens real-time test page)
echo     3. Dentia Bridge Data Folder (Opens logs and captures)
echo ==============================================================================
echo.
timeout /t 5
